﻿using System;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;

namespace dotnet_code_challenge
{
    class Program
    {
        static void Main(string[] args)
        {
            Fetch_WolferhamptonRace_HorseNames();
        }

        /// <summary>
        /// Fetch Horse Names in Price ascending order from Wolferhampton Race
        /// </summary>
        private static void Fetch_WolferhamptonRace_HorseNames()
        {
            try
            {
                string wolferhamptonRaceJsonObject = LoadJson();
                if (!string.IsNullOrEmpty(wolferhamptonRaceJsonObject))
                {
                    RootObject rootObject = JsonConvert.DeserializeObject<RootObject>(wolferhamptonRaceJsonObject);
                    Dictionary<string, double> horseList = new Dictionary<string, double>();
                    //List<Selection> selectionList = rootObject.RawData.Markets.Select(m => m.Selections);
                    // = rootObject.RawData.Markets.Select(m =>m.Selections.Select(p => p.Price));

                    foreach (List<Selection> selection in rootObject.RawData.Markets.Select(m => m.Selections))
                    {
                        
                        double price = selection.Select(s => s.Price).ToList() as double;

                       // horseList.Add();
                    }
                        
                        

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to Print Horse Names in Ascending Order Wolferhampton Race. " + ex.Message);
            }
        }

        /// <summary>
        /// Read json feed data of Wolferhampton Race
        /// </summary>
        /// <returns>string</returns>
        private static string LoadJson()
        {
            try
            {
                string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"FeedData\Wolferhampton_Race1.json");
                using (StreamReader file = File.OpenText(path))
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    JObject o2 = (JObject)JToken.ReadFrom(reader);
                    return o2.ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to Load JSON file for Wolferhampton Race. " + ex.Message);
                return string.Empty;
            }
        }
    }
}
